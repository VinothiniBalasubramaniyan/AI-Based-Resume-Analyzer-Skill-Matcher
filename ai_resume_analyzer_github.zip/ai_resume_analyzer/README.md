# 🤖 AI Resume Analyzer

**AI-Powered Resume Analysis using NLP, WordNet WSD, and Sentence-BERT**

A web application that analyzes your resume against a job description and gives a match score with improvement suggestions.

---

## 🚀 Demo

Upload your resume PDF + paste a job description → Get instant match score and feedback!

---

## ✨ Features

- 📄 **PDF Text Extraction** — Reads resume from PDF using PyPDF2
- 🧹 **NLP Preprocessing** — Cleaning, Tokenization, Lemmatization via spaCy
- 🧠 **Word Sense Disambiguation** — Simplified Lesk Algorithm using NLTK WordNet
- 🎯 **Skill Extraction** — Detects 100+ technical skills, actions, and attributes
- 🔍 **Semantic Matching** — Sentence-BERT (all-MiniLM-L6-v2) for deep similarity
- 📊 **Smart Scoring** — 70% semantic + 30% skill overlap = Final Score
- 💡 **Suggestions** — Personalized improvement tips based on missing skills
- 🗂️ **JSON Output** — Structured data export of all extracted entities

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| Web UI | Gradio |
| PDF Parsing | PyPDF2 |
| NLP | spaCy (`en_core_web_sm`) |
| WSD | NLTK WordNet |
| Semantic Matching | Sentence-Transformers (BERT) |
| Language | Python 3.8+ |

---

## 📁 Project Structure

```
ai_resume_analyzer/
│
├── app.py                    ← Main application (run this)
├── requirements.txt          ← All dependencies
├── .gitignore
│
└── modules/
    ├── __init__.py
    ├── extractor.py          ← PDF text extraction (PyPDF2)
    ├── preprocess.py         ← Text cleaning (spaCy)
    ├── wordnet_module.py     ← Word Sense Disambiguation (NLTK)
    ├── entity_extractor.py   ← Skill/Action/Attribute extraction
    ├── json_generator.py     ← JSON output generation
    ├── matcher.py            ← Sentence-BERT semantic matching
    └── scorer.py             ← Score calculation & classification
```

---

## ⚙️ Setup & Installation

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/ai-resume-analyzer.git
cd ai-resume-analyzer
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Download spaCy model
```bash
python -m spacy download en_core_web_sm
```

### 5. Run the app
```bash
python app.py
```

### 6. Open in browser
```
http://localhost:7861
```

---

## 📊 Scoring Logic

```
Final Score = (Semantic Similarity × 70) + (Skill Overlap × 30)
```

| Score | Classification |
|-------|---------------|
| 75–100 | ✅ RECOMMENDED |
| 55–74  | 👍 GOOD |
| 35–54  | ⚠️ AVERAGE |
| 0–34   | 🔴 BAD |

---

## 📦 Requirements

```
gradio
PyPDF2
spacy
nltk
sentence-transformers
```

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.

---

## 📄 License

MIT License
